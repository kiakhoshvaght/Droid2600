package com.barang.omenoapp.Helpers;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.barang.omenoapp.ModelClasses.Users;

public class UsersDbHelper extends SQLiteOpenHelper {
    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + Users.TableProperty.TABLE_NAME + " (" +
                    Users.TableProperty._ID + " INTEGER PRIMARY KEY," +
                    Users.TableProperty.COLUMN_NAME_AdroidId + " TEXT," +
                    Users.TableProperty.COLUMN_NAME_Day + " TEXT,"+
                    Users.TableProperty.COLUMN_NAME_Month + " TEXT," +
                    Users.TableProperty.COLUMN_NAME_Year + " TEXT)";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + Users.TableProperty.TABLE_NAME;

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "Users.db";

    public UsersDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }
}
