package com.barang.omenoapp.ModelClasses;

public enum Month {
    FARVARDIN("فروردین", 1),
    ORDIBEHESHT("اردیبهشت", 2),
    KHORDAD("خرداد", 3),
    TIR("تیر", 4),
    MORDAD("مرداد", 5),
    SHAHRIVAR("شهریور", 6),
    MEHR("مهر", 7),
    ABAN("آبان", 8),
    AZAR("آذر", 9),
    DEY("دی", 10),
    BAHMAN("بهمن", 11),
    ESFAND("اسفند", 12);

    private String stringValue;
    private int intValue;
    private Month(String toString, int value) {
        stringValue = toString;
        intValue = value;
    }

    @Override
    public String toString() {
        return stringValue;
    }
}
