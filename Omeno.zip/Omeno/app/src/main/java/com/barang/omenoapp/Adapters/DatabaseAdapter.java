package com.barang.omenoapp.Adapters;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class DatabaseAdapter extends SQLiteOpenHelper {

    static String DB_PATH = "/data/data/com.barang.omenoapp/databases/";
    static String DB_NAME = "AstrologyDB";
    public SQLiteDatabase db;
    private final Context mContext;

    public DatabaseAdapter(Context context) {
        super(context, DB_NAME, null, 1);
        this.mContext = context;
    }


    public void createDB(){
        boolean dbExist = checkDB();
        if (dbExist) {

        } else {
            this.getReadableDatabase();

            try {
                copyDBFile();
                File zipFile = new File(DB_PATH + DB_NAME + ".zip");
                unzip(zipFile);
            } catch (Exception e) {
                e.printStackTrace();
                throw new Error("Error copying DB");
            }
        }
    }

    private void copyDBFile() throws IOException {

        File file = new File(DB_PATH + DB_NAME + ".zip");
        if(file.exists()){
            return;
        }
        else{
            InputStream dbInput = mContext.getAssets().open(DB_NAME + ".zip");
            String outFile = DB_PATH + DB_NAME + ".zip";
            OutputStream dbOutput = new FileOutputStream(outFile);

            byte[] buffer = new byte[1024];
            int length;
            while ((length = dbInput.read(buffer))>0) {
                dbOutput.write(buffer,0,length);
            }

            dbOutput.flush();
            dbOutput.close();
            dbInput.close();
        }
    }

    public static void unzip(File zipFile) throws IOException {
        ZipInputStream zis = new ZipInputStream(
                new BufferedInputStream(new FileInputStream(zipFile)));
        try {
            ZipEntry ze;
            int count;
            byte[] buffer = new byte[8192];
            while ((ze = zis.getNextEntry()) != null) {
                File file = new File(DB_PATH, ze.getName());
                File dir = ze.isDirectory() ? file : file.getParentFile();
                if (!dir.isDirectory() && !dir.mkdirs())
                    throw new FileNotFoundException("Failed to ensure directory: " +
                            dir.getAbsolutePath());
                if (ze.isDirectory())
                    continue;
                FileOutputStream fout = new FileOutputStream(file);
                try {
                    while ((count = zis.read(buffer)) != -1)
                        fout.write(buffer, 0, count);
                } finally {
                    fout.close();
                }
            }
        } finally {
            zis.close();
        }
    }

    private boolean checkDB() {
        SQLiteDatabase check = null;
        try {
            String dbPath = DB_PATH+DB_NAME;
            check = SQLiteDatabase.openDatabase(dbPath, null, SQLiteDatabase.OPEN_READONLY);
        } catch (Exception e) {
            // TODO: handle exception
        }
        if (check!=null) {
            check.close();
        }

        return check != null ? true : false;
    }

    public void openDB(){
        String dbPath = DB_PATH+DB_NAME;
        db = SQLiteDatabase.openDatabase(dbPath, null, SQLiteDatabase.OPEN_READONLY);
    }

    public synchronized void close(){
        if(db != null)
            db.close();
        super.close();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
}

