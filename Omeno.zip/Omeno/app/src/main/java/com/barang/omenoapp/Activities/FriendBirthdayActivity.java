package com.barang.omenoapp.Activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.NumberPicker;

import com.barang.omenoapp.ModelClasses.Month;
import com.barang.omenoapp.ModelClasses.PersonType;
import com.barang.omenoapp.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class FriendBirthdayActivity extends Activity implements  View.OnClickListener {
    private static final String TAG= FriendBirthdayActivity.class.getName();
    public static final int REQ_CODE=12;
    int input_year;
    int input_month;
    int input_day;
    PersonType input_user =PersonType.FRIEND;

    @BindView(R.id.show_faal)
    protected Button show_faal_btn;
    @BindView(R.id.year)
    protected NumberPicker year;
    @BindView(R.id.month)
    protected NumberPicker month;
    @BindView(R.id.day)
    protected NumberPicker day;
    @BindView(R.id.back_btn)
    protected Button back_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.i(TAG,"FUNCTION : onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend_birthday);
        ButterKnife.bind(this);
        setNumberPickers();
    }

    @OnClick({
            R.id.show_faal, R.id.back_btn
    })
    public void onClick(View view) {
        Log.i(TAG, "FUNCTION : onClick");
        switch (view.getId()) {
            case R.id.show_faal:
                input_year=year.getValue();
                input_month=month.getValue();
                input_day=day.getValue();
                String text=String.valueOf(input_month);
                Intent intent = new Intent(FriendBirthdayActivity.this, FaalPageActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("year",input_year);
                intent.putExtra("month",input_month);
                intent.putExtra("day",input_day);
                intent.putExtra("WHO",input_user);
                startActivityForResult(intent,REQ_CODE);
                break;
            case R.id.back_btn:
                Intent mainintent=new Intent(FriendBirthdayActivity.this, BaseActivity.class);
                mainintent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(mainintent);
                break;
        }
    }

    private void setNumberPickers() {
        year.setMinValue(1300);
        year.setMaxValue(1397);

        month=findViewById(R.id.month);
        month.setMinValue(1);
        month.setMaxValue(12);
        month.setDisplayedValues( new String[] {Month.FARVARDIN.toString(),Month.ORDIBEHESHT.toString() ,Month.KHORDAD.toString(),Month.TIR.toString(),Month.MORDAD.toString(),
                Month.SHAHRIVAR.toString(),Month.MEHR.toString(),Month.ABAN.toString(),Month.AZAR.toString(),Month.DEY.toString(),Month.BAHMAN.toString(),Month.ESFAND.toString()} );

        day= findViewById(R.id.day);
        day.setMinValue(1);
        day.setMaxValue(31);

        month.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker numberPicker, int i, int i1) {
                Log.i(TAG,"FUNCTION : onCreate => onValueChange");
                if(month.getValue()>=6){
                    day.setMaxValue(30);
                }else{
                    day.setMaxValue(31);
                }
            }
        });
    }

    protected void attachBaseContext(Context newBase) {
        Log.i(TAG,"FUNCTION : onCreate => attachBaseContext");
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
