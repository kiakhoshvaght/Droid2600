package com.barang.omenoapp.Activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.barang.omenoapp.Adapters.DatabaseAdapter;
import com.barang.omenoapp.Helpers.UsersDbHelper;
import com.barang.omenoapp.ModelClasses.Month;
import com.barang.omenoapp.ModelClasses.PersonType;
import com.barang.omenoapp.ModelClasses.Utility;
import com.barang.omenoapp.R;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

public class FaalPageActivity extends Activity {
    private static final String TAG= FaalPageActivity.class.getName();
    PersonType personType;

    @BindView(R.id.date)
    protected TextView txtDate;
    @BindView(R.id.resul_title)
    protected TextView result_title;
    @BindView(R.id.resul_text)
    protected TextView result;
    @BindView(R.id.title)
    protected  TextView title;
    @BindView(R.id.Image_month)
    protected ImageView image_title;
    @BindView(R.id.show_friend_faal)
    protected Button showFriendFaal;
    @BindView(R.id.edit_birthDate)
    protected Button edit_btn;
    @BindView(R.id.share_btn)
    protected Button share_btn;
    @BindView(R.id.back_btn)
    protected Button back_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.i(TAG,"FUNCTION : onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faal_page);
        ButterKnife.bind(this);
        setData();
        handleTheBtns();
    }

    private void handleTheBtns() {
        if(personType.toString().equals("User")){
            title.setText("فال امروزِ شما");
            edit_btn.setBackgroundResource(R.drawable.icon_gear);
            edit_btn.setVisibility(View.VISIBLE);
            edit_btn.setOnClickListener(new View.OnClickListener(){
                public void onClick(View view) {
                    UsersDbHelper usersDbHelper = new UsersDbHelper(getBaseContext());
                    SQLiteDatabase dbRead = usersDbHelper.getReadableDatabase();
                    usersDbHelper.onUpgrade(dbRead,1,1);
                    Intent mainintent=new Intent(FaalPageActivity.this, BaseActivity.class);
                    startActivity(mainintent);
                    finish();
                }
            });
            showFriendFaal.setText("فال دوستتو ببین");
            showFriendFaal.setOnClickListener(new View.OnClickListener(){
                public void onClick(View view) {
                    Intent friendintent=new Intent(FaalPageActivity.this, FriendBirthdayActivity.class);
                    startActivity(friendintent);
                }
            });
            share_btn.setBackgroundResource(R.drawable.share_icon);
            share_btn.setVisibility(View.VISIBLE);
            share_btn.setOnClickListener(new View.OnClickListener(){
                public void onClick(View view) {
                    result=findViewById(R.id.resul_text);
                    String resultString = result.getText().toString();
                    String separated = "فال امروز من" + "\r\n"+ resultString.substring(0,resultString.length()/3).concat("...")+"\r\n"+"http://bit-ly.ir/omeno";
                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT,separated);
                    sendIntent.setType("text/plain");
                    startActivity(sendIntent);
                }
            });
        }else if(personType.toString().equals("Friend")){
            title.setText("فال امروزِ دوست شما");
            showFriendFaal.setText("برای دوستت بفرست");
            showFriendFaal.setOnClickListener(new View.OnClickListener(){
                public void onClick(View view) {
                    String resultString = result.getText().toString();
                    String separated = "فال امروز تو" + "\r\n"+ resultString.substring(0,resultString.length()/3).concat("...")+"\r\n"+"http://bit-ly.ir/omeno" ;
                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND);
                    sendIntent.putExtra(Intent.EXTRA_TEXT,separated);
                    sendIntent.setType("text/plain");
                    startActivity(sendIntent);
                }
            });
            back_btn.setBackgroundResource(R.drawable.back_btn);
            back_btn.setVisibility(View.VISIBLE);
            back_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.i(TAG,"FUNCTION : onCreate => onClick");
                    Intent friendbirth=new Intent(FaalPageActivity.this,FriendBirthdayActivity.class);
                    friendbirth.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(friendbirth);
                }
            });
        }
    }

    private void setData() {
        Utility util = new Utility();
        String currentDate = util.getCurrentShamsidate();
        List<String> date= new ArrayList<String>();
        date=util.getCurrentShamsiDayAndMonth();
        int dayofdate=Integer.parseInt(date.get(0));
        int monthofdate=Integer.parseInt(date.get(1));
        txtDate.setText(currentDate);
        Bundle extras=getIntent().getExtras();
        if(extras!=null) {
            int month = 0;
            if (extras.containsKey("month")) {
                month = extras.getInt("month");
            }
            if (extras.containsKey("WHO")) {
                personType = (PersonType) extras.getSerializable("WHO");
            }

            DatabaseAdapter dbAdopter=new DatabaseAdapter(getApplicationContext());
            dbAdopter.openDB();
            Cursor cursor = dbAdopter.db.query("DailyAstrology", new String[] {"DateMonthSequence", "Day", "BirthMonthName", "BirthDescription"},
                    "DateMonthSequence = "+ monthofdate +" and Day = "+ dayofdate +" and BirthMonthName =  " + month, null, null, null, null);
            String text = "";

            if (cursor.moveToFirst()){
                do{
                    text = cursor.getString(cursor.getColumnIndex("BirthDescription"));
                }while(cursor.moveToNext());
            }
            cursor.close();
            String textTitle="";
            image_title.setImageResource(R.drawable.farvardin);
            switch(month){
                case 1:
                    textTitle= Month.FARVARDIN.toString();
                    image_title.setImageResource(R.drawable.farvardin);
                    break;
                case 2 :
                    textTitle= Month.ORDIBEHESHT.toString();
                    image_title.setImageResource(R.drawable.ordibehesht);
                    break;
                case 3 :
                    textTitle= Month.KHORDAD.toString();
                    image_title.setImageResource(R.drawable.khordad);
                    break;
                case 4 :
                    textTitle= Month.TIR.toString();
                    image_title.setImageResource(R.drawable.tir);
                    break;
                case 5 :
                    textTitle= Month.MORDAD.toString();
                    image_title.setImageResource(R.drawable.mordad);
                    break;
                case 6 :
                    textTitle= Month.SHAHRIVAR.toString();
                    image_title.setImageResource(R.drawable.shahrivar);
                    break;
                case 7 :
                    textTitle= Month.MEHR.toString();
                    image_title.setImageResource(R.drawable.mehr);
                    break;
                case 8 :
                    textTitle= Month.ABAN.toString();
                    image_title.setImageResource(R.drawable.aban);
                    break;
                case 9 :
                    textTitle= Month.AZAR.toString();
                    image_title.setImageResource(R.drawable.azar);
                    break;
                case 10 :
                    textTitle= Month.DEY.toString();
                    image_title.setImageResource(R.drawable.dey);
                    break;
                case 11 :
                    textTitle= Month.BAHMAN.toString();
                    image_title.setImageResource(R.drawable.bahman);
                    break;
                case 12 :
                    textTitle= Month.ESFAND.toString();
                    image_title.setImageResource(R.drawable.esfand);
                    break;
            }
            result.setText(text);
            result_title.setText(textTitle);
        }
    }

    protected void attachBaseContext(Context newBase) {
        Log.i(TAG,"FUNCTION : onCreate => attachBaseContext");
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
