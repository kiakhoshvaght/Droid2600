package com.barang.omenoapp.ModelClasses;

import android.provider.BaseColumns;

public class Users {

    private int DateMonthSequence;
    private int Day;
    private String BirthMonthName;
    private String BirthDescription;

    public Users(){}

    public static class TableProperty implements BaseColumns {
        public static final String TABLE_NAME = "Users";
        public static final String COLUMN_NAME_AdroidId = "AndroidId";
        public static final String COLUMN_NAME_Day = "Day";
        public static final String COLUMN_NAME_Month = "Month";
        public static final String COLUMN_NAME_Year = "Year";
    }

}

