package com.barang.omenoapp.ModelClasses;

public enum PersonType {
    USER("User", 0),
    FRIEND("Friend", 1);

    private String stringValue;
    private int intValue;
    private PersonType(String toString, int value) {
        stringValue = toString;
        intValue = value;
    }

    @Override
    public String toString() {
        return stringValue;
    }
}
