package com.barang.omenoapp.Activities;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.provider.Settings.Secure;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.NumberPicker;

import com.barang.omenoapp.Adapters.DatabaseAdapter;
import com.barang.omenoapp.Helpers.UsersDbHelper;
import com.barang.omenoapp.ModelClasses.Month;
import com.barang.omenoapp.ModelClasses.PersonType;
import com.barang.omenoapp.ModelClasses.Users;
import com.barang.omenoapp.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;



public class BaseActivity extends Activity implements View.OnClickListener{
    private static final String TAG = BaseActivity.class.getName();
    public static final int REQ_CODE=12;
    int input_year;
    int input_month;
    int input_day;
    PersonType input_user = PersonType.USER;
    SharedPreferences prefs = null;
    String android_id;

    @BindView(R.id.show_faal)
    protected Button show_faal_btn;
    @BindView(R.id.year)
    protected NumberPicker year;
    @BindView(R.id.month)
    protected NumberPicker month;
    @BindView(R.id.day)
    protected NumberPicker day;

    @SuppressLint("LongLogTag")
    protected void onCreate(Bundle savedInstanceState) {
        Log.i(TAG,"FUNCTION : onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        setDbAdopter();
        setNumberPickers();
    }

    @OnClick({
            R.id.show_faal
    })
    public void onClick(View view) {
        Log.i(TAG, "FUNCTION : onClick");
        switch (view.getId()) {
            case R.id.show_faal:
                input_year=year.getValue();
                input_month = month.getValue();
                input_day=day.getValue();
                String text=String.valueOf(input_month);
                //Save User In DataBaseA
                UsersDbHelper usersDbHelper = new UsersDbHelper(getBaseContext());
                SQLiteDatabase dbWrite = usersDbHelper.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put(Users.TableProperty.COLUMN_NAME_AdroidId, android_id);
                values.put(Users.TableProperty.COLUMN_NAME_Day, input_day);
                values.put(Users.TableProperty.COLUMN_NAME_Month,input_month);
                values.put(Users.TableProperty.COLUMN_NAME_Year,input_year);
                long newRowId = dbWrite.insert(Users.TableProperty.TABLE_NAME, null, values);
                //go to Second Activity
                Intent intent = new Intent(BaseActivity.this,FaalPageActivity.class);
                intent.putExtra("year",input_year);
                intent.putExtra("month",input_month);
                intent.putExtra("day",input_day);
                intent.putExtra("WHO",input_user);
                startActivityForResult(intent,REQ_CODE);
                finish();
                break;
        }
    }

    private void setNumberPickers() {
        year = findViewById(R.id.year);
        year.setMinValue(1300);
        year.setMaxValue(1397);

        month=findViewById(R.id.month);
        month.setMinValue(1);
        month.setMaxValue(Month.values().length);
        month.setDisplayedValues( new String[] {Month.FARVARDIN.toString(),Month.ORDIBEHESHT.toString() ,Month.KHORDAD.toString(),Month.TIR.toString(),Month.MORDAD.toString(),
                Month.SHAHRIVAR.toString(),Month.MEHR.toString(),Month.ABAN.toString(),Month.AZAR.toString(),Month.DEY.toString(),Month.BAHMAN.toString(),Month.ESFAND.toString()} );
        day= findViewById(R.id.day);
        day.setMinValue(1);
        day.setMaxValue(31);

        month.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker numberPicker, int i, int i1) {
                day.setMaxValue(month.getValue()>6 ? 30 : 31);
            }
        });
    }

    private void setDbAdopter() {
        DatabaseAdapter dbAdopter=new DatabaseAdapter(getApplicationContext());
        dbAdopter.createDB();
        android_id = Secure.getString(getBaseContext().getContentResolver(),Secure.ANDROID_ID);
        UsersDbHelper usersDbHelper = new UsersDbHelper(getBaseContext());
        SQLiteDatabase dbRead = usersDbHelper.getReadableDatabase();
        String[] projection = {
                BaseColumns._ID,
                Users.TableProperty.COLUMN_NAME_AdroidId,
                Users.TableProperty.COLUMN_NAME_Day,
                Users.TableProperty.COLUMN_NAME_Month,
                Users.TableProperty.COLUMN_NAME_Year
        };
        String selection = Users.TableProperty.COLUMN_NAME_AdroidId + " = ?";
        String[] selectionArgs = { android_id };
        Cursor cursor = dbRead.query(Users.TableProperty.TABLE_NAME,projection, selection,selectionArgs,null,null,null);
        if (cursor.moveToFirst()){
            do{
                input_year =cursor.getInt(cursor.getColumnIndex("Year"));
                input_month =cursor.getInt(cursor.getColumnIndex("Month"));
                input_day = cursor.getInt(cursor.getColumnIndex("Day"));
                Intent intent = new Intent(BaseActivity.this, FaalPageActivity.class);
                intent.putExtra("year",input_year);
                intent.putExtra("month",input_month);
                intent.putExtra("day",input_day);
                intent.putExtra("WHO",input_user);
                startActivityForResult(intent,REQ_CODE);
                finish();
            }while(cursor.moveToNext());
        }
        cursor.close();
    }

    @Override
    protected void onStop() {
        Log.i(TAG,"FUNCTION : onStop");
        super.onStop();
    }

    protected void attachBaseContext(Context newBase) {
        Log.i(TAG,"FUNCTION : attachBaseContext");
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }
}
