package com.barang.omenoapp;

import android.app.Application;
import android.util.Log;

import uk.co.chrisjenx.calligraphy.CalligraphyConfig;

public class OmenoApplication extends Application {
    private static final String TAG = OmenoApplication.class.getName();
    @Override
    public void onCreate() {
        Log.i(TAG,"FUNCTION : onCreate");
        super.onCreate();
        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("fonts/IRANYekanMobileBold(FaNum).ttf")
                .setFontAttrId(R.font.mobile_bold)
                .build()
        );
    }
}